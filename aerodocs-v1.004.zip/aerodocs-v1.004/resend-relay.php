<?php
/* AeroDocs v1.004 — Resend relay. Keeps the Resend API key server-side.
   1. Set the four values below.  2. Upload next to index.html.  3. In AeroDocs → Email → Resend, enter this file's URL and RELAY_TOKEN. */
$RESEND_KEY     = 're_REPLACE_ME';                       // Resend API key (never put this in the app)
$RELAY_TOKEN    = 'REPLACE_WITH_LONG_RANDOM_STRING';     // shared secret typed into AeroDocs
$ALLOWED_TO     = 'you@example.com';                     // only address this relay will send to
$FROM           = 'AeroDocs <alerts@your-verified-domain.com>'; // must be a Resend-verified domain

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$self   = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '');
if ($origin === $self) { header('Access-Control-Allow-Origin: ' . $origin); header('Vary: Origin'); }
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST')    { http_response_code(405); echo '{"error":"POST only"}'; exit; }

$in = json_decode(file_get_contents('php://input'), true);
if (!is_array($in) || !hash_equals($RELAY_TOKEN, (string)($in['token'] ?? ''))) { http_response_code(401); echo '{"error":"bad token"}'; exit; }
if (strcasecmp(trim((string)($in['to'] ?? '')), $ALLOWED_TO) !== 0) { http_response_code(403); echo '{"error":"recipient not allowed"}'; exit; }

$subject = mb_substr(strip_tags((string)($in['subject'] ?? 'AeroDocs alert')), 0, 200);
$text    = mb_substr((string)($in['text'] ?? ''), 0, 20000);

$ch = curl_init('https://api.resend.com/emails');
curl_setopt_array($ch, [
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $RESEND_KEY, 'Content-Type: application/json'],
  CURLOPT_POSTFIELDS => json_encode(['from' => $FROM, 'to' => [$ALLOWED_TO], 'subject' => $subject, 'text' => $text]),
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT => 15,
]);
$res  = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
http_response_code($code ?: 502);
echo $res ?: '{"error":"upstream unreachable"}';
